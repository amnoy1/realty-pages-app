import type { Metadata } from "next";
import { Heebo } from "next/font/google";
import "./globals.css";
import React from "react";
import { NextRouterProvider } from "../components/RouterContext";

const heebo = Heebo({ subsets: ["hebrew", "latin"] });

export const metadata: Metadata = {
  title: "מחולל דפי נחיתה לנדל\"ן",
  description: "אפליקציה ליצירת דפי נחיתה מקצועיים וממירים עבור נכסי נדל\"н, עם תיאור נכס משודרג באמצעות AI.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="he" dir="rtl">
      <body className={`${heebo.className} bg-slate-900 text-white`}>
        <NextRouterProvider>
          {children}
        </NextRouterProvider>
      </body>
    </html>
  );
}