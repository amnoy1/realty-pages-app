
import { GoogleGenAI } from "@google/genai";

export async function POST(request: Request) {
  const apiKey = process.env.API_KEY;

  if (!apiKey) {
    return new Response(JSON.stringify({ error: "Server configuration error" }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  const ai = new GoogleGenAI({ apiKey });

  try {
    const { originalDescription, address, targetAudience, title } = await request.json();
    
    const audienceString = targetAudience && targetAudience.length > 0 
      ? targetAudience.join(", ") 
      : "קהל רחב המחפש איכות חיים";

    const systemInstruction = `
    You are an Expert Real Estate Marketing Strategist in Israel.
    Your tone: Premium, professional, and highly persuasive.
    Target Audience for this property: ${audienceString}.
    
    Rules:
    1. Language: Hebrew.
    2. Format: Return valid JSON ONLY.
    3. Focus on selling points that matter to the selected audience.
    `;

    const prompt = `
    Create a marketing package for this property:
    User's Title: ${title}
    Address: ${address}
    Description: "${originalDescription}"
    Target Audience: ${audienceString}

    JSON Structure:
    {
      "title": "A highly catchy marketing headline",
      "description": {
        "area": "Neighborhood vibe and location benefits for the target audience.",
        "property": "Specific features that appeal to the audience.",
        "cta": "Urgent call to action"
      },
      "features": {
        "rooms": "extracted number",
        "apartmentArea": "extracted sqm",
        "balconyArea": "extracted sqm",
        "floor": "extracted floor",
        "parking": "count",
        "elevator": "יש/אין",
        "safeRoom": "יש/אין",
        "storage": "יש/אין",
        "airDirections": "directions"
      }
    }
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
      },
    });

    return new Response(response.text, {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error("Gemini Error:", error);
    return new Response(JSON.stringify({ error: "Failed to generate content" }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' },
    });
  }
}
