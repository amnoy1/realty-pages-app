
import React, { useState, useRef } from 'react';
import type { PropertyFormData } from '../types';

// --- Icons ---
const BuildingIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>;
const MapPinIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>;
const PriceIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;
const UserIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>;
const EmailIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>;
const WhatsAppIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2a10 10 0 0 0-10 10c0 1.88.52 3.64 1.45 5.15L2 22l5.26-1.38A9.95 9.95 0 0 0 12 22a10 10 0 1 0 0-20zm0 18.27c-1.48 0-2.92-.4-4.22-1.07l-.3-.16-3.13.82.83-3.05-.18-.28c-1.05-1.68-1.61-3.64-1.61-5.63 0-5.5 4.47-9.97 9.97-9.97s9.97 4.47 9.97 9.97-4.47 9.97-9.97 9.97z"/></svg>;
const UploadIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" /></svg>;
const TrashIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>;

interface CreationFormProps {
  onSubmit: (data: PropertyFormData) => void;
  isLoading: boolean;
}

const AUDIENCE_OPTIONS = ["משקיעים", "משפחות", "משפרי דיור", "זוגות צעירים", "גיל שלישי", "דיור בר השגה"];

export const CreationForm: React.FC<CreationFormProps> = ({ onSubmit, isLoading }) => {
  const [formData, setFormData] = useState<PropertyFormData>({
    title: '',
    address: '',
    description: '',
    price: '',
    agentName: '',
    agentEmail: '',
    agentWhatsApp: '',
    images: [],
    targetAudience: [],
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleAudienceToggle = (option: string) => {
    setFormData(prev => {
      const current = prev.targetAudience || [];
      const updated = current.includes(option)
        ? current.filter(item => item !== option)
        : [...current, option];
      return { ...prev, targetAudience: updated };
    });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      const filePromises = files.map((file) => new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
          if (typeof reader.result === 'string') {
            resolve(reader.result);
          } else {
            reject(new Error("Failed to process image"));
          }
        };
        reader.onerror = () => reject(new Error("File reading error"));
        reader.readAsDataURL(file);
      }));

      Promise.all(filePromises).then((base64Images: string[]) => {
        setFormData((prev) => ({
          ...prev,
          images: [...prev.images, ...base64Images],
        }));
      }).catch(err => {
        console.error("Upload error:", err);
        alert("אירעה שגיאה בעיבוד התמונות.");
      });
    }
  };

  const removeImage = (index: number) => {
    setFormData(prev => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.images.length === 0) {
      alert("נא להוסיף לפחות תמונה אחת של הנכס.");
      return;
    }
    onSubmit(formData);
  };

  const inputClasses = "w-full pr-12 pl-4 py-4 bg-slate-800 border border-slate-700 rounded-2xl text-white placeholder-slate-500 focus:ring-2 focus:ring-brand-accent outline-none transition-all shadow-inner font-medium";
  const iconContainerClasses = "absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none";
  const labelClasses = "block text-sm font-bold text-slate-400 mb-2 mr-1 uppercase tracking-wider";

  return (
    <div className="max-w-4xl mx-auto px-4 py-12 md:py-20 animate-fade-in" dir="rtl">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-black text-white mb-4 tracking-tight">יצירת דף נחיתה</h1>
        <p className="text-slate-400 text-lg font-medium">מלאו את הפרטים וה-AI יבנה לכם דף שיווקי ממיר</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-10">
        {/* Step 1: Core Details */}
        <div className="bg-slate-900/50 p-8 md:p-10 rounded-[2.5rem] border border-slate-800 shadow-2xl relative overflow-hidden">
          <h3 className="text-2xl font-bold text-white mb-8 flex items-center gap-3">
             <span className="w-8 h-8 rounded-lg bg-brand-accent/20 text-brand-accent flex items-center justify-center text-sm font-mono">01</span>
             פרטי הנכס
          </h3>
          <div className="space-y-6">
            <div className="space-y-2">
              <label htmlFor="title" className={labelClasses}>כותרת הנכס (למשל: פנטהאוז 5 חדרים יוקרתי)</label>
              <div className="relative">
                <div className={iconContainerClasses}><BuildingIcon /></div>
                <input type="text" name="title" id="title" className={inputClasses} placeholder="מה הכותרת שתרצו להציג?" value={formData.title} onChange={handleChange} required />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label htmlFor="address" className={labelClasses}>כתובת מלאה</label>
                  <div className="relative">
                    <div className={iconContainerClasses}><MapPinIcon /></div>
                    <input type="text" name="address" id="address" className={inputClasses} placeholder="רחוב ומספר, עיר" value={formData.address} onChange={handleChange} required />
                  </div>
                </div>
                <div className="space-y-2">
                  <label htmlFor="price" className={labelClasses}>מחיר מבוקש (₪)</label>
                  <div className="relative">
                    <div className={iconContainerClasses}><PriceIcon /></div>
                    <input type="text" name="price" id="price" className={inputClasses} placeholder="לדוגמה: 3,200,000" value={formData.price} onChange={handleChange} required />
                  </div>
                </div>
            </div>
          </div>
        </div>

        {/* Step 2: Target Audience */}
        <div className="bg-slate-900/50 p-8 md:p-10 rounded-[2.5rem] border border-slate-800 shadow-2xl">
           <h3 className="text-2xl font-bold text-white mb-8 flex items-center gap-3">
             <span className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center text-sm font-mono">02</span>
             קהל יעד ושיווק
           </h3>
           <div className="space-y-8">
              <div className="space-y-4">
                <label className={labelClasses}>מי קהל היעד שלכם? (ניתן לבחור כמה)</label>
                <div className="flex flex-wrap gap-2">
                  {AUDIENCE_OPTIONS.map((option) => (
                    <button
                      key={option}
                      type="button"
                      onClick={() => handleAudienceToggle(option)}
                      className={`px-5 py-2.5 rounded-xl text-sm font-bold transition-all border-2 ${
                        (formData.targetAudience || []).includes(option)
                          ? 'bg-brand-accent border-brand-accent text-white shadow-lg'
                          : 'bg-slate-800 border-slate-700 text-slate-400 hover:border-slate-500'
                      }`}
                    >
                      {option}
                    </button>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <label htmlFor="description" className={labelClasses}>תיאור חופשי ומפרט</label>
                <textarea name="description" id="description" rows={6} className="w-full p-6 bg-slate-800 border border-slate-700 rounded-3xl text-white placeholder-slate-500 focus:ring-2 focus:ring-brand-accent outline-none transition-all font-medium resize-none" placeholder="ספרו לנו על הנכס: קומה, כיווני אוויר, שיפוץ, מרפסת, חניה..." value={formData.description} onChange={handleChange} required />
              </div>
           </div>
        </div>

        {/* Step 3: Images */}
        <div className="bg-slate-900/50 p-8 md:p-10 rounded-[2.5rem] border border-slate-800 shadow-2xl">
          <h3 className="text-2xl font-bold text-white mb-8 flex items-center gap-3">
             <span className="w-8 h-8 rounded-lg bg-green-500/20 text-green-400 flex items-center justify-center text-sm font-mono">03</span>
             תמונות (לפחות אחת)
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            <button type="button" onClick={() => fileInputRef.current?.click()} className="aspect-square bg-slate-800 border-2 border-dashed border-slate-700 rounded-2xl flex flex-col items-center justify-center text-slate-500 hover:border-brand-accent hover:text-brand-accent transition-all group">
              <UploadIcon />
              <span className="text-xs font-bold mt-2">העלאה</span>
              <input type="file" ref={fileInputRef} className="hidden" multiple accept="image/*" onChange={handleFileChange} />
            </button>
            {formData.images.map((img, index) => (
              <div key={index} className="aspect-square relative rounded-2xl overflow-hidden border border-slate-700 group">
                <img src={img} alt="" className="w-full h-full object-cover transition-transform group-hover:scale-110" />
                <button type="button" onClick={() => removeImage(index)} className="absolute top-2 right-2 p-1.5 bg-red-600/80 text-white rounded-lg opacity-0 group-hover:opacity-100 transition-opacity">
                  <TrashIcon />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Step 4: Contact */}
        <div className="bg-slate-900/50 p-8 md:p-10 rounded-[2.5rem] border border-slate-800 shadow-2xl">
          <h3 className="text-2xl font-bold text-white mb-8 flex items-center gap-3">
             <span className="w-8 h-8 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center text-sm font-mono">04</span>
             פרטי קשר של הסוכן
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <label htmlFor="agentName" className={labelClasses}>שם מלא</label>
              <div className="relative">
                <div className={iconContainerClasses}><UserIcon /></div>
                <input type="text" name="agentName" id="agentName" className={inputClasses} placeholder="שם הסוכן" value={formData.agentName} onChange={handleChange} required />
              </div>
            </div>
            <div className="space-y-2">
              <label htmlFor="agentEmail" className={labelClasses}>אימייל</label>
              <div className="relative">
                <div className={iconContainerClasses}><EmailIcon /></div>
                <input type="email" name="agentEmail" id="agentEmail" className={inputClasses} placeholder="example@agency.com" value={formData.agentEmail} onChange={handleChange} required />
              </div>
            </div>
            <div className="space-y-2">
              <label htmlFor="agentWhatsApp" className={labelClasses}>טלפון וואטסאפ</label>
              <div className="relative">
                <div className={iconContainerClasses}><WhatsAppIcon /></div>
                <input type="tel" name="agentWhatsApp" id="agentWhatsApp" className={inputClasses} placeholder="972..." value={formData.agentWhatsApp} onChange={handleChange} required />
              </div>
            </div>
          </div>
        </div>

        <button type="submit" disabled={isLoading} className="w-full py-6 px-10 rounded-3xl bg-gradient-to-r from-brand-accent to-orange-600 text-white text-2xl font-black shadow-xl hover:shadow-brand-accent/40 transform hover:-translate-y-1 transition-all disabled:opacity-50">
          {isLoading ? (
            <div className="flex items-center justify-center gap-4">
               <div className="w-8 h-8 border-4 border-white/30 border-t-white rounded-full animate-spin"></div>
               <span>ה-AI מנתח את הנכס...</span>
            </div>
          ) : 'בנה לי דף נחיתה עכשיו'}
        </button>
      </form>
    </div>
  );
};
