
import { GoogleGenAI } from "@google/genai";

export async function POST(request: Request) {
  const apiKey = process.env.API_KEY || 
                 process.env.GEMINI_API_KEY || 
                 process.env.NEXT_PUBLIC_API_KEY || 
                 process.env.NEXT_PUBLIC_GEMINI_API_KEY;

  if (!apiKey) {
    return new Response(JSON.stringify({ 
        error: "Server configuration error: API_KEY is missing." 
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  const ai = new GoogleGenAI({ apiKey });

  try {
    const { originalDescription, address, targetAudience } = await request.json();
    
    if (!originalDescription || !address) {
        return new Response(JSON.stringify({ error: "Missing originalDescription or address" }), {
            status: 400,
            headers: { 'Content-Type': 'application/json' },
        });
    }

    const audienceString = targetAudience && targetAudience.length > 0 && !targetAudience.includes("לא רלבנטי") 
      ? targetAudience.join(", ") 
      : "קהל כללי";

    const systemInstruction = `
    You are an Expert Real Estate Copywriter and Strategist, writing in Hebrew.
    
    MISSION: Customize marketing copy for: [${audienceString}].
    
    STRATEGY:
    - Families: Safety, schools, parks, rooms, memories.
    - Investors: Yield, demand, location potential.
    - Upgraders: Luxury, balcony, status, size.
    - Adults: Accessibility, elevator, quiet, services nearby.
    
    RULES:
    1. Title: powerful hook for ${audienceString}.
    2. CLEAN TEXT ONLY: No Markdown formatting.
    3. Lot Area: Specifically look for land area ("שטח מגרש").
    `;

    const prompt = `
    Analyze property for ${audienceString}.
    Address: ${address}
    Input: "${originalDescription}"

    JSON Output:
    {
      "title": "Headline",
      "description": {
        "area": "Marketing text about area for ${audienceString} (50 words).",
        "property": "Marketing text about property for ${audienceString} (50 words).",
        "cta": "Urgent CTA"
      },
      "features": {
        "rooms": "Number",
        "apartmentArea": "Number",
        "lotArea": "Number",
        "balconyArea": "Number",
        "floor": "Number",
        "parking": "Number",
        "elevator": "יש/אין",
        "safeRoom": "ממ\"ד/אין",
        "storage": "יש/אין",
        "airDirections": "כיוונים"
      }
    }
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
      },
    });

    return new Response(response.text, {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });

  } catch (error) {
    return new Response(JSON.stringify({ error: "API Failure" }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' },
    });
  }
}
