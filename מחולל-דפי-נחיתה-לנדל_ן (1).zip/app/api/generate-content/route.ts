
import { GoogleGenAI } from "@google/genai";

// We strictly read the API key inside the handler to avoid build-time caching issues
export async function POST(request: Request) {
  // Try multiple naming conventions to be helpful to the user
  const apiKey = process.env.API_KEY || 
                 process.env.GEMINI_API_KEY || 
                 process.env.NEXT_PUBLIC_API_KEY || 
                 process.env.NEXT_PUBLIC_GEMINI_API_KEY;

  if (!apiKey) {
    console.error("CRITICAL ERROR: API_KEY is missing from server environment variables.");
    return new Response(JSON.stringify({ 
        error: "Server configuration error: API_KEY is missing." 
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  // Initialize client per request to ensure it uses the current key
  const ai = new GoogleGenAI({ apiKey });

  try {
    const { originalDescription, address, targetAudience } = await request.json();
    
    if (!originalDescription || !address) {
        return new Response(JSON.stringify({ error: "Missing originalDescription or address in request body" }), {
            status: 400,
            headers: { 'Content-Type': 'application/json' },
        });
    }

    const audienceString = targetAudience && targetAudience.length > 0 && !targetAudience.includes("לא רלבנטי") 
      ? targetAudience.join(", ") 
      : "קהל כללי";

    // System instruction updated to include target audience logic
    const systemInstruction = `
    You are an Expert Real Estate Marketing Copywriter and Strategist, writing in Hebrew.
    
    CRITICAL MISSION: Customize the marketing copy for the following Target Audience: [${audienceString}].
    
    COPYWRITING STRATEGY PER AUDIENCE:
    - Families: Emphasize safety, community, schools, parks, space, and family memories.
    - Investors: Focus on ROI, yield, demand, location potential, and low maintenance.
    - Upgraders (משפרי דיור): Highlight luxury, premium finishes, balcony, status, and improved lifestyle.
    - Adults/Downsizers: Emphasize accessibility, elevator, convenience, quiet neighborhood, and proximity to services.
    
    TASK 1: CREATIVE COPYWRITING (For 'title' and 'description' fields)
    Transform the user's input into high-converting Hebrew marketing copy targeted at ${audienceString}.
    
    COPYWRITING RULES:
    1.  **Headline (Title):** Create a powerful hook specifically for ${audienceString}.
    2.  **Specifics over Generics:** Use vivid, descriptive Hebrew.
    3.  **Action Verbs:** Use words like "תגלו", "תתאהבו", "תחוו".
    4.  **CLEAN TEXT ONLY:** Do NOT use Markdown formatting. Return clean, plain text.
    
    TASK 2: STRICT DATA EXTRACTION (For 'features' object)
    1.  **NO HALLUCINATIONS:** If a feature is not explicitly written in the text, return an empty string "".
    2.  **Exact Numbers:** Extract numbers accurately.
    3.  **Lot Area:** Specifically look for mentions of "שטח מגרש" or land area.
    
    OUTPUT FORMAT: JSON ONLY.
    `;

    const prompt = `
    Analyze the following property.
    Target Audience: ${audienceString}
    Address: ${address}
    Description: "${originalDescription}"

    Required Output JSON Format:
    {
      "title": "A targeted headline for ${audienceString}",
      "description": {
        "area": "Marketing text about the area tailored for ${audienceString} (approx 50 words).",
        "property": "Marketing text about the property tailored for ${audienceString} (approx 50 words).",
        "cta": "Urgent Call to Action for ${audienceString}"
      },
      "features": {
        "rooms": "Number",
        "apartmentArea": "Number",
        "lotArea": "Number",
        "balconyArea": "Number",
        "floor": "Number",
        "parking": "Number",
        "elevator": "יש/אין",
        "safeRoom": "ממ\"ד/אין",
        "storage": "יש/אין",
        "airDirections": "כיוונים"
      }
    }
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
      },
    });

    const responseText = response.text;
    
    if (!responseText) {
      throw new Error("Gemini API returned an empty text response.");
    }
    
    return new Response(responseText, {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error("Error in API route:", error);
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
    return new Response(JSON.stringify({ error: errorMessage }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' },
    });
  }
}
