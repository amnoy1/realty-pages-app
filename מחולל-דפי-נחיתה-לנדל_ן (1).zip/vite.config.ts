// This file is intentionally left empty.
// It is created to override a stray file that was causing build errors on Vercel.
// Since this is a Next.js project, this Vite config file is not needed and should be empty.